
import java.util.Comparator;
import java.util.LinkedList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author invitado
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        LinkedList<Integer> lista = new LinkedList<>();
        for (int i = 0; i < 15; i++) {
            lista.add((int) (Math.random() * 20));
        }
        System.out.println(lista);
        System.out.println("\nTamaño de la lista: " + lista.size());
        Comparator c = new Comparator() {
            @Override
            public int compare(Object o1, Object o2) {
                int resu;
                //CERO --> IGUAL
                //POSITIVO --> MAYOR
                //NEGATIVO --> MENOR
                Integer val1, val2;
                val1 = (Integer) o1;
                val2 = (Integer) o2;
                resu = val1 - val2;
                //o1 - o2 --> MENOR A MAYOR
                //o1 - o2 --> MAYOR A MENOR
                return resu;
            }
        };
        lista.sort(c);
        System.out.println(lista);

        LinkedList<String> listaStr = new LinkedList<>();
        listaStr.add("Hola");
        listaStr.add(" ");
        listaStr.add("Mundo");
        listaStr.add(" ");
        listaStr.add("Cruel");
        listaStr.add("!!");

        Comparator cStr = new Comparator() {
            @Override
            public int compare(Object o1, Object o2) {
                String cade1 = (String) o1;
                String cade2 = (String) o2;
                char c1 = cade1.charAt(0);
                char c2 = cade2.charAt(0);
                return c1 - c2;
            }
        };
        System.out.println(listaStr);
        listaStr.sort(cStr);
        System.out.println(listaStr);

    }
}
